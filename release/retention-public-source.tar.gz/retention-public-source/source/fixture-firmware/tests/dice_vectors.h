struct vector {const char*id;unsigned words,mode;const char*rolls;int rc;const char*hex,*mn;};
static const struct vector vectors[]={
{"coldcard-12",12,1,"12345612345612345612345612345612345612345612345612",0,"ee72ae915a4e6ea7ccbeb8e5e5eecef2","unveil nice picture region tragic fault cream strike tourist control recipe tourist"},
{"coleman-12",12,2,"12345612345612345612345612345612345612345612345612",0,"2794d19f669d8be8aa6999f0e594a264","chest pledge guitar snake suffer violin predict creek valley coach chuckle sister"},
{"coldcard-15",15,1,"12345612345612345612345612345612345612345612345612345612345612",0,"499a3794957e43570fd55d0e2aca3d6f5f06e1f2","end spider topple cliff tomorrow process dismiss produce athlete film monster team vacant ill silk"},
{"coleman-15",15,2,"12345612345612345612345612345612345612345612345612345612345612",0,"47fcf6649e328d897cef6ec2c6b7c9ec7c12a219","elevator tray odor detect churn seven victory universe security cup venue suggest scorpion extra gun"},
{"coldcard-18",18,1,"123456123456123456123456123456123456123456123456123456123456123456123456123",0,"8aa5181a5c05913512bb03ac159085c995e4ed0c2bed8419","melt churn alley retreat flip once enough gather project prosper cannon nasty furnace isolate cost laundry lottery slice"},
{"coleman-18",18,2,"123456123456123456123456123456123456123456123456123456123456123456123456123",0,"5b71595a9230496527b287f24b7ba2169b21d4a94c67999f","fork member find caught afraid raw paddle extend venture forward trigger coffee rare tumble pioneer mind office wife"},
{"coldcard-21",21,1,"123456123456123456123456123456123456123456123456123456123456123456123456123456123456123",0,"d4ae9c1f2917b35ba78da3195d1348426cb99fad98e6b5b2ce076d87","start insane amazing fall kite punch owner refuse bone trigger spirit luggage slide sound reopen broom remember nose limb swallow kitten"},
{"coleman-21",21,2,"123456123456123456123456123456123456123456123456123456123456123456123456123456123456123",0,"e286c083de3c75cfb390e17fa5c85ef63512d8baf97ed8b5a0249c05","tip current can round shrug treat soft bring leisure comic bless unaware eye hobby typical cool suffer public ankle day explain"},
{"coldcard-24",24,1,"123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123",1,"5588d3630bd19f6375b7bd922457af34ea9c74f00807566a1cf808e445dc8c20","few educate sugar bless boring random strategy waste mutual cargo type hawk prefer denial scan abstract filter extend dignity balcony dust unusual correct bubble"},
{"coleman-24",24,2,"123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123",1,"d75f271db1335f983f37e061f4b2bd50d87641dcc0d4f2f9324a57abb25d7459","struggle weird shuffle give curious slot wolf winter giggle pitch quantum payment manual can indoor box very sister myth quantum robot concert sphere chase"},
{"coldcard-single",12,1,"6",1,"e7f6c011776e8db7cd330b54174fd76f","tree render affair uphold trip swim crumble gesture favorite risk volume test"},
{"coldcard-separators",12,1,"1,2;3|4\n5 6",-4,"8d969eef6ecad3c29a3a629280e686cf","mirror reject rookie talk pudding throw happy era myth already payment owner"},
{"coldcard-invalid",12,1,"1230",-4,"-","-"},
{"coldcard-empty",12,1,"",-1,"-","-"},
{"coldcard-excess",12,1,"123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456",0,"6f30370babf7d7dffdfb7d756b046fc0","hundred like seed fitness latin useful wave hurry install flag brief lesson"},
{"coleman-single",12,2,"6",1,"5feceb66ffc86f38d952786c6d696c79","garment guard super zebra manage organ grab excuse hockey hero force vessel"},
{"coleman-separators",12,2,"1,2;3|4\n5 6",-4,"eb76e2254ff1cb43115299491e1906fb","twin require matter paper bronze pave earn farm empower valid double voyage"},
{"coleman-invalid",12,2,"1230",-4,"-","-"},
{"coleman-empty",12,2,"",-1,"-","-"},
{"coleman-excess",12,2,"123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456123456",0,"ad0f64b8c0fae4fc87b6e0ae001b34e0","public kite comfort limit purity layer burst swing puppy absorb snake scissors"}
};
static const char *fullhex[]={"259339b0bb91cea0710ad54d2625fc2eb247929f6c388978db2225082f41bfdd","35ae5091b37e8f0f306833ef57a635f9dc06738d7f4e563a610eec2adb26fe28"};
