# Retention public source successor — packaging candidate only

RELEASE HOLD. This is an offline source/provenance archive, not hardware GO,
publisher authentication, independent reproducibility, or permission to deploy.
Only the retained application is a browser payload; browser writes remain disabled.

## Portable verification recipe
Obtain the SHA256 of `public-inventory.json` from an independently reviewed channel
(the adjacent export receipt is a local trust anchor, not a signature). Then run:

    python3 verify-public.py --anchor TRUSTED_INVENTORY_SHA256

No network, builds, runtime tests, source imports or device operations occur.
The exact inventory covers the validator itself and rejects any missing/extra file.
Immutable record pins and six independently frozen before/after identities constrain
the delta even if an attacker refreshes the outer inventory. Never regenerate pins
as part of validation. A maliciously replaced validator cannot authenticate itself;
review its bytes and the independent anchor before executing downloaded code.

`provenance/recipe.json` defines the finite mapping. The source is exactly 745 files,
437 matching the reviewed target identity; 301 license/notice-named files unchanged.
The ignored `source/fixture-firmware/app/sdkconfig` is explicitly present and hashed.
Do not substitute git archive: it can omit this required build input.

## History is not repinned
All source744 inventory assertions and historical scripts/manifests are unchanged.
The shipped historical `source/scripts/d6-release/verify-source.py` intentionally
REJECTS current modified source at gui.c. That is expected, not an error to suppress.
To reconstruct source744 in a separate directory: copy source, overlay the five
`history/original/` files at matching relative paths, remove only the one added
navigation test recorded in recipe.json, then compare all 744 original inventory
hashes. The original history checker accepts that projection. This is an archival
projection, NEVER a substitute for executing successor runtime tests.

The additive validator verifies inventory/delta/identity/license/browser linkage;
it does not run or replace historical runtime suites. Existing full-host driver
principles require explicit historical projections at provenance boundaries and
preservation of every runtime command; no full-host integration execution is claimed
here. No target or host build was rerun. Target identity to application binding is
inherited from the reviewed artifact, not independently reconstructed.

Installed boot/table pins and older artifact/upstream digests inside byte-preserved
historical manifests are historical commitments, not downloadable browser payloads.
Current public manifest identity/allowlist records and their immediate record chain
are bundled. This is not a complete content-addressed archive of every transitive
upstream or historical binary digest. Preserve that distinction during review.

## Publication review still required
Review validator/recipe and public metadata, independent trust-anchor delivery,
license coverage, and any demand for transitive historical blob closure separately.
Operation budget, hardware/browser qualification and release authorization remain HOLD.
