#!/usr/bin/env python3
"""Bounded, offline packaging validator. Does not execute source code or build firmware."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,sys,stat
PINS = {'provenance/original744.json': '8f5c85923c67ddd86af3f18e8e5610a4f134623f61be795efc2ef1d94b75e0d4', 'provenance/owner-source-sha256.json': '401f183b23ef950b8d2eceacdd2c1338043622ba4eb0a82c6684a3006ece4cf7', 'provenance/recipe.json': 'caa027a551267a08220245964c57d2a164c267143d2a0eeac7d1bd9721683caa', 'provenance/records/31aa5c3236c1da74a55b5c1878c3f9b0a8c6c14df72269310b3bd1a58a279a30.json': '31aa5c3236c1da74a55b5c1878c3f9b0a8c6c14df72269310b3bd1a58a279a30', 'provenance/source-allowlist.json': '7a9e89b51c433ccccc5594e5c376e03193f39e5a0bd285c8b6d1ca4e7cfabb10', 'provenance/target-source-identity.json': '5d730162bc966e98c45868cdc5acf1414f63a2abecfa20c2390dd6cdcd640778'}
DELTA = [{'baseline_sha256': '98db499ddfd502f402016de46968857edf8e388f266ed821e647bbf35af8dd61', 'candidate_sha256': '572bba9eeca5fb1de691acaa494b57207690f75f4cec55dfb38c87b033035ddb', 'classification': 'production', 'path': 'fixture-firmware/app/main/gui.c', 'rationale': 'Reviewed dice result retention successor; exact reviewed source, not target approval.'}, {'baseline_sha256': '7586a9fbd5838c653606f7b2579f9535e822db6356993046fe4e21b1b75e9573', 'candidate_sha256': '4765aebd92d768128f727a7a0b6e0162d788bf3fdee80496c999de7106ca7cc5', 'classification': 'production', 'path': 'fixture-firmware/app/main/passphrase_gui.inc', 'rationale': 'Reviewed dice result retention successor; exact reviewed source, not target approval.'}, {'baseline_sha256': '27af1da5fc572c46eec944ba9129a9f7fcffd1a1d237ba13962a1f09fe1684c9', 'candidate_sha256': 'df6c40d2aae187928ee6065efd3aef5227538f3ae0388ad54dceecbd3067a11b', 'classification': 'production', 'path': 'fixture-firmware/app/main/passphrase_integration.inc', 'rationale': 'Reviewed dice result retention successor; exact reviewed source, not target approval.'}, {'baseline_sha256': None, 'candidate_sha256': '03a34994a3a19f24c45aed6ad3682580f90daf2c6eeac8f9b0f9eb1301c30b70', 'classification': 'test', 'path': 'fixture-firmware/tests/dice_navigation_tests.inc', 'rationale': 'Reviewed dice result retention successor; exact reviewed source, not target approval.'}, {'baseline_sha256': '991792ef78011558a88b474a25ec75f6a9b09cf3f6ebc074344d48c32b695aa2', 'candidate_sha256': '97e17a8eeac935ff2db330647f2a00732769695f9cd0fb1d048a425aa7435be9', 'classification': 'test', 'path': 'fixture-firmware/tests/gui_host.c', 'rationale': 'Reviewed dice result retention successor; exact reviewed source, not target approval.'}, {'baseline_sha256': '5c90bb34943abe9c8a59a7b53aa28df7c09bf3ca0558532f759a8ecdb805c074', 'candidate_sha256': '86338993b9bc1ab80bbdf79e353d5c75a7f558576cc99cf1badc810dc57bcfda', 'classification': 'test', 'path': 'fixture-firmware/tests/passphrase_gui_tests.inc', 'rationale': 'Reviewed dice result retention successor; exact reviewed source, not target approval.'}]
APP='a02a2192b5c302390a916f9ee67961b699e5f2f9038135378eed0b19d792f33b'
def require(ok,msg):
 if not ok:raise ValueError(msg)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def unique(pairs):
 d={}
 for k,v in pairs:
  require(k not in d,'duplicate JSON key');d[k]=v
 return d
def load(p):
 require(p.stat().st_size<2000000,'record size bound')
 return json.loads(p.read_text(),object_pairs_hook=unique)
def safe(root,name):
 q=PurePosixPath(name);require(name==str(q) and not q.is_absolute() and '..' not in q.parts and '\\' not in name and name not in ('','.'),'unsafe path')
 p=root
 for part in q.parts:
  p=p/part;require(not p.is_symlink(),'symlink forbidden')
 return p
def inventory(root):
 d={};total=0
 for p in root.rglob('*'):
  require(not p.is_symlink(),'symlink forbidden')
  if p.is_dir():continue
  require(stat.S_ISREG(p.stat().st_mode),'nonregular file')
  total+=p.stat().st_size;require(total<100000000 and len(d)<2000,'inventory budget')
  d[p.relative_to(root).as_posix()]=sha(p)
 return d
def verify(root,anchor):
 require(not root.is_symlink(),'root symlink')
 require(sha(root/'public-inventory.json')==anchor,'independent inventory anchor mismatch')
 pub=load(root/'public-inventory.json')['files'];actual=inventory(root)
 require(actual==dict(pub,**{'public-inventory.json':anchor}),'exact public inventory mismatch')
 for n,h in PINS.items():require(sha(safe(root,n))==h,'immutable record drift: '+n)
 a=load(root/'provenance/source-allowlist.json');old=load(root/'provenance/original744.json');recipe=load(root/'provenance/recipe.json')
 require(a['changes']==DELTA and recipe['changes']==DELTA,'unapproved finite delta')
 def files(m):
  d={}
  for f in m['files']:
   n=f['path'];safe(root/'source',n);require(n not in d,'duplicate source');d[n]=f['sha256']
  return d
 base=files(old);cur=files(a)
 require(len(base)==744 and len(cur)==745 and inventory(root/'source')==cur,'source inventory')
 changed=sorted(n for n in base if cur.get(n)!=base[n]);added=sorted(set(cur)-set(base))
 require(len(changed)==5 and len(added)==1 and not set(base)-set(cur),'delta counts')
 require(set(changed+added)=={c['path'] for c in DELTA},'unknown change')
 for c in DELTA:
  n=c['path'];require(base.get(n)==c['baseline_sha256'] and cur[n]==c['candidate_sha256'],'delta hash continuity')
  if n in base:require(sha(safe(root/'history/original',n))==base[n],'historical bytes')
 notices=[n for n in cur if 'LICENSE' in n or 'NOTICES' in n]
 require(len(notices)==301 and all(cur[n]==base[n] for n in notices),'license continuity')
 require(a['predecessor_inventory_sha256']==sha(root/'provenance/original744.json'),'inventory ancestry')
 identity=load(root/'provenance/target-source-identity.json');m=load(root/'flash/publicrelease-manifest.json')
 require(len(identity['source_paths'])==437,'identity count')
 for n,h in identity['source_paths'].items():require(cur.get(n)==h,'target identity mismatch')
 require(identity['owner_manifest_sha256']==sha(root/'provenance/owner-source-sha256.json'),'owner record')
 require(identity['predecessor_identity_sha256']==sha(root/'source/docs/d6-release/candidate-source-identity.json'),'D6 predecessor')
 require(m['source_identity_sha256']==sha(root/'provenance/target-source-identity.json') and m['source_allowlist_sha256']==sha(root/'provenance/source-allowlist.json'),'browser record binding')
 require(m['writes_enabled'] is False and m['allowed_modes']==['appupdate'],'release hold')
 require(len(m['images'])==1,'app only')
 image=m['images'][0];p=safe(root/'flash',image['path'])
 require(sha(p)==APP==image['sha256'] and p.stat().st_size==image['bytes']==1539952,'application binding')
 require('fixture-firmware/app/sdkconfig' in cur,'missing ignored sdkconfig')
 # Historical inventory metadata points to preserved records, not repinned current assertions.
 hashes=set(actual.values())
 for k in ['candidate_identity_sha256','historical_recipe_manifest_sha256','closure_manifest_sha256']:
  require(old[k] in hashes,'unresolved historical record: '+k)
 print('PASS packaging only: source745, identity437, delta5+1, notices301; runtime NOT executed; RELEASE HOLD')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--anchor',required=True);a=p.parse_args()
 try:verify(a.root,a.anchor)
 except (ValueError,OSError,KeyError,TypeError) as e:print('FAIL:',e,file=sys.stderr);sys.exit(1)
